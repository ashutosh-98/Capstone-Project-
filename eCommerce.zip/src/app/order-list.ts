export class OrderList {
    constructor(public itemId:number, public itemName:string, public itemCategory:string, public itemDescription:string, public itemPrice:number, public itemImageName:string, public itemQuantity:number)
    {}
}
