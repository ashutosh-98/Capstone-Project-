import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {TalkWithDbService} from '../talk-with-db.service'
import { Item } from '../item'
import { OrderList } from '../order-list'


@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  uservalidationFailedmessage:string;
  loginForm= new FormGroup({
    userName:new FormControl("",Validators.required),
    password:new FormControl("",[Validators.required,Validators.minLength(8)])
  })
  currentOrder:OrderList[]=new Array();
  cardArr:Item[]= new Array();
  temp:Item;
  currentItemCount:number;
  currentCartCount:number;
  currentUsername:string;
  currentCategory:string;
  loggedin:boolean;
  userCount:number;
  allUsers:any[]=new Array();
  

  constructor(public router:Router, public talkWithDbService: TalkWithDbService) {
    this.currentCartCount=0;
    this.loggedin=false;
    //console.log("first");
    this.talkWithDbService.getAllUsers().subscribe((data)=>{
      this.allUsers=data as string[];
      console.log("user count",this.allUsers[0]['userName']);
      this.currentUsername=this.allUsers[0]['userName'];
      if(this.currentUsername=="Guest")
      {
        console.log("Before login");
        //this.currentUsername="Guest";
        this.loggedin=false;
      }

      else
      {
        console.log("After login");
        //this.currentUsername=this.allUsers[1];
        this.loggedin=true;
      }
      },
      (err)=>{
        console.log(err);
    });
   }

  ngOnInit(): void {
    this.talkWithDbService.countAllOrders().subscribe((data)=>{
      //console.log("Get all orders",data);
      this.currentOrder=data as OrderList[];
      console.log("Get all orders",this.currentOrder);
      for(let i=0;i<this.currentOrder.length;i++)
      {
        this.currentCartCount+=this.currentOrder[i]['itemQuantity'];
        //console.log("After login cart count", this.currentOrder[i]);
      }
      
    },
    (err)=>{
      console.log(err);
    });
    
  }

  loginEventHandler(){
    var user={
      userName:this.loginForm.value.userName,
      password:this.loginForm.value.password
    }
    console.log(user);
    this.talkWithDbService.doUserValidation(user).subscribe((data)=>{
      console.log(data);
      var tempObj:any=data["message"];
      if(tempObj == true)
      {
        var user={userName:this.loginForm.value.userName};
        this.talkWithDbService.updateUser(user).subscribe((data)=>{
          console.log(data);
        },
        (err)=>{
          console.log(err);
        });
        this.router.navigateByUrl("/home/"+user.userName);
      }
      else
      {
        this.uservalidationFailedmessage="Please enter correct username and password";
      }
    },
    (err)=>{
      console.log(err);
    });
    
  }

}
