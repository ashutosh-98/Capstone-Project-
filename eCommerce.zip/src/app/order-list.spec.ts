import { OrderList } from './order-list';

describe('OrderList', () => {
  it('should create an instance', () => {
    expect(new OrderList()).toBeTruthy();
  });
});
