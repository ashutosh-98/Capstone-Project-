import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {TalkWithDbService} from './talk-with-db.service'
import {Router} from '@angular/router';
import { Item } from './item'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'eCommerce';
  order:Item[]= new Array();
  username:string;

  constructor(public activatedRoute:ActivatedRoute,public router:Router, public talkWithDbService:TalkWithDbService) {
    this.username="Guest";
    this.talkWithDbService.deleteMany({}).subscribe((data)=>{
      //console.log(data);
    },
    (err)=>{
      //console.log(err);
    });
    this.talkWithDbService.deletemanyOrder({}).subscribe((data)=>{
      //console.log(data);
    },
    (err)=>{
      //console.log(err);
    });
    var user={
      userName:this.username,
      orderlist:this.order
    }
    this.talkWithDbService.insertUser(user).subscribe((data)=>{
      //console.log(data);
    },
    (err)=>{
      //console.log(err);
    });
    // this.router.navigateByUrl("/home");
    }
  
  
}
