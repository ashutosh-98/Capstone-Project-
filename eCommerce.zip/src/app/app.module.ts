import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { TalkWithDbService} from './talk-with-db.service'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './home-page/home-page.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { SignUpPageComponent } from './sign-up-page/sign-up-page.component';
import { ViewCartComponent } from './view-cart/view-cart.component';
import { CheckOutComponent } from './check-out/check-out.component';
import { MenItemsComponent } from './men-items/men-items.component';
import { WomenItemsComponent } from './women-items/women-items.component';
import { KidsItemsComponent } from './kids-items/kids-items.component';
import { ElectronicsItemsComponent } from './electronics-items/electronics-items.component';
import { SportsItemsComponent } from './sports-items/sports-items.component';
import { StartComponent } from './start/start.component';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    LoginPageComponent,
    SignUpPageComponent,
    ViewCartComponent,
    CheckOutComponent,
    MenItemsComponent,
    WomenItemsComponent,
    KidsItemsComponent,
    ElectronicsItemsComponent,
    SportsItemsComponent,
    StartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [TalkWithDbService],
  bootstrap: [AppComponent]
})
export class AppModule { }
