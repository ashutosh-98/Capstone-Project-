var express=require("express");
//const itemControllers = require("../controllers/itemControllers");
var router=express.Router();

var itemControllers=require("../controllers/itemControllers");
//const { checkUser } = require("../controllers/userControllers");

router.get("/",itemControllers.getAllItems);
//router.get("/",itemControllers.getAllItemsbyCategory);

module.exports=router;