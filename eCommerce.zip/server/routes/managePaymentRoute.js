var express=require("express");
var router=express.Router();

var managePaymentController=require("../controllers/managePaymentController");
//const { checkUser } = require("../controllers/userControllers");

//router.post("/",userController.checkUser);
router.post("/addnewpayment",managePaymentController.addPayment);

module.exports=router;