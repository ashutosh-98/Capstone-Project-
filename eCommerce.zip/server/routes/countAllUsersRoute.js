var express=require("express");
var router=express.Router();

var countAllUsersController=require("../controllers/countAllUsersController");
//const { checkUser } = require("../controllers/userControllers");

router.get("/",countAllUsersController.countUser);

module.exports=router;