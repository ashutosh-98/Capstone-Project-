var express=require("express");
var router=express.Router();

var deleteUserRoute=require("../controllers/deleteUsersController");
//const { checkUser } = require("../controllers/userControllers");

//router.post("/",userController.checkUser);
router.post("/",deleteUserRoute.deleteMany);
router.post("/deleteManyOrder", deleteUserRoute.deleteManyOrder);

module.exports=router;