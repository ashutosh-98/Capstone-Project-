var express=require("express");
var router=express.Router();

var manageUsers=require("../controllers/manageUsers");
//const { checkUser } = require("../controllers/userControllers");

//router.post("/",userController.checkUser);
router.post("/",manageUsers.insertUser);
router.get("/currentusers",manageUsers.getAllUsers);
router.post("/loginUpdate",manageUsers.updateUser);
router.post("/addnewuser",manageUsers.addNewUser);


module.exports=router;