const { MongoClient } = require("mongodb");

var mongoClient=require("mongodb").MongoClient;
var mongodbUrl="mongodb://localhost:27017";

function getAllQuestions(req,res)
{
    MongoClient.connect(mongodbUrl,{useUnifiedTopology:true},(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message:"Error connecting to the server"});
        }
        else
        {
            var db=dbHost.db("slDbMean");
            db.collection("questionsColl",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message:"Error connecting to the server"});
                }
                else
                {
                    coll.find({}).toArray((err,data)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:"Error connecting to the server"});
                        }
                        else
                        {
                            console.log("Result of find all questions",data);
                            res.json(data);
                        }
                    })
                }
            })
        }
    })
}

module.exports={getAllQuestions};