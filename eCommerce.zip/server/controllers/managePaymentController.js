var mongoClient=require("mongodb").MongoClient;

var mongodbUrl="mongodb://localhost:27017/";

function addPayment(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("paymentHistory",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    var itemToBeInserted=req.body;
                    var order={
                        userName:itemToBeInserted.currentUsername,
                        orderList:itemToBeInserted.cardArr,
                        totalPay:itemToBeInserted.totalSum,
                        name:itemToBeInserted.name,
                        email:itemToBeInserted.email,
                        address:itemToBeInserted.address,
                        city:itemToBeInserted.city,
                        state:itemToBeInserted.state,
                        zip:itemToBeInserted.zip,
                        nameOnCard:itemToBeInserted.nameOnCard,
                        creditCardNumber:itemToBeInserted.creditCardNumber,
                        expiryMonth:itemToBeInserted.expiryMonth,
                        expiryYear:itemToBeInserted.expiryYear,
                        cvv:itemToBeInserted.cvv
                      }
                    console.log("In add payment");
                    coll.insertOne(order,(err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:err});
                        }
                        else
                        {
                            if(result)
                            {
                                //console.log("In usercontroller",result);
                                res.status(200);
                                res.json({message:true});
                            }
                            else
                            {
                                res.status(201);
                                res.json({message:false});
                            }
                        }
                    })
                }

            })
        }
    })
}



module.exports={addPayment};