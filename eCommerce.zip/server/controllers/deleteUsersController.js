var mongoClient=require("mongodb").MongoClient;

var mongodbUrl="mongodb://localhost:27017/";

function deleteMany(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("currentUsers",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    //var userToBeInserted=req.body;
                    //var user={userName:userToBeInserted.userName,orderList:userToBeInserted.orderList};
                    console.log("In delete all");
                    coll.deleteMany({},(err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:err});
                        }
                        else
                        {
                            if(result)
                            {
                                //console.log("In usercontroller",result);
                                res.status(200);
                                res.json({message:true});
                            }
                            else
                            {
                                res.status(201);
                                res.json({message:false});
                            }
                        }
                    })
                }

            })
        }
    })
}

function deleteManyOrder(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("currentOrders",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    //var userToBeInserted=req.body;
                    //var user={userName:userToBeInserted.userName,orderList:userToBeInserted.orderList};
                    console.log("In delete all orders");
                    coll.deleteMany({},(err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:err});
                        }
                        else
                        {
                            if(result)
                            {
                                //console.log("In usercontroller",result);
                                res.status(200);
                                res.json({message:true});
                            }
                            else
                            {
                                res.status(201);
                                res.json({message:false});
                            }
                        }
                    })
                }

            })
        }
    })
}

module.exports={deleteMany,deleteManyOrder};