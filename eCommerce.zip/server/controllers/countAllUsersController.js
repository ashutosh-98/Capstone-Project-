var mongoClient=require("mongodb").MongoClient;

var mongodbUrl="mongodb://localhost:27017/";

function countUser(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("currentUsers",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    //var userToBeInserted=req.body;
                    //var user={userName:userToBeInserted.userName,orderList:userToBeInserted.orderList};
                    //console.log("In insert user", user);
                    coll.count({},(err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json(result);
                        }
                        else
                        {
                            console.log("in count",result);
                            res.json(result);
                        }
                    })
                }

            })
        }
    })
}






module.exports={countUser};