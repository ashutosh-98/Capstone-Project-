var mongoClient=require("mongodb").MongoClient;

var mongodbUrl="mongodb://localhost:27017/";

function addOrder(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("currentOrders",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    var itemToBeInserted=req.body;
                    var item={
                        itemId:itemToBeInserted.itemId,
                        itemName:itemToBeInserted.itemName,
                        itemCategory:itemToBeInserted.itemCategory,
                        itemDescription:itemToBeInserted.itemDescription,
                        itemPrice:itemToBeInserted.itemPrice,
                        itemImageName:itemToBeInserted.itemImageName,
                        itemQuantity:itemToBeInserted.itemQuantity
                    };
                    console.log("In add order");
                    coll.insertOne(item,(err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:err});
                        }
                        else
                        {
                            if(result)
                            {
                                //console.log("In usercontroller",result);
                                res.status(200);
                                res.json({message:true});
                            }
                            else
                            {
                                res.status(201);
                                res.json({message:false});
                            }
                        }
                    })
                }

            })
        }
    })
}

function getAllOrders(req, res)
{
    mongoClient.connect(mongodbUrl,{useUnifiedTopology:true},(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message:"Error connecting to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("currentOrders",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message:"Error connecting to the server"});
                }
                else
                {
                    coll.find().toArray((err,data)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:"Error connecting to the server"});
                        }
                        else
                        {
                            console.log("Result of find all questions",data);
                            res.json(data);
                        }
                    })
                }
            })
        }
    })
}


module.exports={addOrder,getAllOrders};