var mongoClient=require("mongodb").MongoClient;

var mongodbUrl="mongodb://localhost:27017/";
function getAllItems(req, res)
{
    mongoClient.connect(mongodbUrl,{useUnifiedTopology:true},(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message:"Error connecting to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("itemsColl",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message:"Error connecting to the server"});
                }
                else
                {
                    coll.find({}).toArray((err,data)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:"Error connecting to the server"});
                        }
                        else
                        {
                            console.log("Result of find all questions",data);
                            res.json(data);
                        }
                    })
                }
            })
        }
    })
}

function getAllItemsbyCategory(req,res)
{
    mongoClient.connect(mongodbUrl,{useUnifiedTopology:true},(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message:"Error connecting to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("itemsColl",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message:"Error connecting to the server"});
                }
                else
                {
                    var itemsToBeFind=req.body;
                    coll.find({itemCategory:itemsToBeFind.itemCategory}).toArray((err,data)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:"Error connecting to the server"});
                        }
                        else
                        {
                            console.log("Result of find all items",data);
                            res.json(data);
                        }
                    })
                }
            })
        }
    })
}

module.exports={getAllItems,getAllItemsbyCategory};