var mongoClient=require("mongodb").MongoClient;

var mongodbUrl="mongodb://localhost:27017/";

function insertUser(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("currentUsers",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    var userToBeInserted=req.body;
                    var user={userName:userToBeInserted.userName};
                    console.log("In insert user", user);
                    coll.insertOne(user,(err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:err});
                        }
                        else
                        {
                            if(result)
                            {
                                //console.log("In usercontroller",result);
                                res.status(200);
                                res.json({message:true});
                            }
                            else
                            {
                                res.status(201);
                                res.json({message:false});
                            }
                        }
                    })
                }

            })
        }
    })
    
}

function getAllUsers(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("currentUsers",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    //var userToBeChecked=req.body;
                    coll.find({}).toArray((err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:"Error connecting to the server"});
                        }
                        else
                        {
                            console.log("Result of find all users",result);
                            res.json(result);
                        }
                    })
                }

            })
        }
    })
}


function updateUser(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("currentUsers",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    var userToBeInserted=req.body;
                    var user={userName:userToBeInserted.userName};
                    var filterQuery={
                        userName: "Guest"
                    }
                    var updateQuery={
                        $set:{userName:user.userName}
                    }
                    console.log("In update user", user);
                    coll.updateOne(filterQuery,updateQuery,(err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:err});
                        }
                        else
                        {
                            if(result)
                            {
                                //console.log("In usercontroller",result);
                                res.status(200);
                                res.json({message:true});
                            }
                            else
                            {
                                res.status(201);
                                res.json({message:false});
                            }
                        }
                    })
                }

            })
        }
    })
    
}



function addNewUser(req, res)
{
    mongoClient.connect(mongodbUrl,(err,dbHost)=>{
        if(err)
        {
            res.status(500);
            res.json({message: "Not able to connect to the server"});
        }
        else
        {
            var db=dbHost.db("eCommerce");
            db.collection("allUsers",(err,coll)=>{
                if(err)
                {
                    res.status(500);
                    res.json({message: "Not able to connect to the server"});
                }
                else
                {
                    var userToBeInserted=req.body;
                    var user={
                        name:userToBeInserted.name, 
                        userName:userToBeInserted.userName,
                        password:userToBeInserted.password,
                        email:userToBeInserted.email
                    };
                    console.log("In insert user", user);
                    coll.insertOne(user,(err,result)=>{
                        if(err)
                        {
                            res.status(500);
                            res.json({message:err});
                        }
                        else
                        {
                            if(result)
                            {
                                //console.log("In usercontroller",result);
                                res.status(200);
                                res.json({message:true});
                            }
                            else
                            {
                                res.status(201);
                                res.json({message:false});
                            }
                        }
                    })
                }

            })
        }
    })
    
}





module.exports={insertUser,getAllUsers,updateUser,addNewUser};