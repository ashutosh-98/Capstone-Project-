var express=require("express");
var bodyParser=require("body-parser");
var path=require("path");
var cors=require("cors");

var userRoute=require("./routes/userRoute");
var itemRoute=require("./routes/itemRoute");
var manageUsersRoute=require("./routes/manageUsersRoute");
var deletUserRoute=require("./routes/deletUserRoute");
var countAllUsers=require("./routes/countAllUsersRoute");
var manageOrderRoute=require("./routes/manageOrderRoute");
var managepaymentRoute=require("./routes/managePaymentRoute")

var PORT=3000;

var app=express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use(cors());

app.use("/api/login",userRoute);
app.use("/api/home",itemRoute);
app.use("/api/user",manageUsersRoute);
app.use("/api/delete",deletUserRoute);
app.use("/api/getCount",countAllUsers);
app.use("/api/order",manageOrderRoute);
app.use("/api/payment",managepaymentRoute);



app.listen(PORT,(err)=>{
    if(!err)
    {
        console.log(`Serever is running at PORT ${PORT}`);
    }
})