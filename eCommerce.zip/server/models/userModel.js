class Users{
    userName;
    password;
    constructor(userName, password)
    {
        this.userName=userName;
        this.password=password;
    }
}

module.exports=Users;